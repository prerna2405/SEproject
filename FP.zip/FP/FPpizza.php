<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: FPlogin.htm");
exit(); }
?>

<html>
<head>
<title>Welcome <?php echo $_SESSION["username"] ?></title>
<link rel="icon" href="D:\SEM3\soft engg\project\Feaster'spizza\logo.jpg"/>
<style>

.footer{
   top: 94%;
   position:fixed;
   bottom:0;
   width:100%;
   height: 25 px;
   background: rgba(0,0,0,0.5);
   color: #F0F8FF;
}

.topnav {
  overflow: hidden;
  background-color: black;
  margin-right:6px; 
  border-bottom:4px red solid;
}

.topnav a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 20px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: #4CAF50;
    color: white;
}

.heading1 h2{
    display: block;
    background: black;
    margin-left:44%;
    color: #E9967A;
}

.container {
  width:100%;
  position: relative;
  top: 45;
  bottom: 0;
  left: 0;
  right: 0;
  margin: ;
}

.innercon1{
  width:49%;
  position:absolute;
  height:100%;
}

.innercon2{
   width:49%;
  position:absolute;
  height:100%;
  left:50%;
  float:right;
 }

.veg{
  text-align:center;
  border: 2px solid #E9967A;
  width:100%;
  height:100%;
  color: white;
  }

.nvbutton {
  padding: 7px 7px;
  font-size: 13px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #E9967A;
  border: none;
  border-radius: 15px;
  box-shadow: 0 3px #999;
}

.nvbutton:hover {background-color: red}

.vbutton {
  padding: 7px 7px;
  font-size: 13px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 3px #999;
}

.vbutton:hover {background-color: green}

</style>
</head>
<body style="background-color:#333">
<form name="order" action="FPcart.php" method="post">
<div class="topnav">
<a href="FPlogout.php">Logout</a>
<a href="FPcart.php"><input type="submit" value="My cart"></a>
<a href="FPhome.php">Home</a>
<div style="float:left">
</div>
<div class="heading1">
<h2>PIZZAS</h2>
</div>
</div>
<br>
<hr width="100%" size="3px" color="white">
<div class="container">
<div class="innercon1">
<table class="veg" cellspacing="10px">
 <tr><th colspan="2" bgcolor="green"><font size="6px">Vegetarian pizzas</font></th></tr>
 <tr><td height="380px" background="margherita.jpg"></td><td height="380px" background="farmfresh.jpg"></td></tr>
 <tr><td height="40px" bgcolor="white"><font color="black">Rs.250 </font>&nbsp;<input type="number" name="marg"><button class="vbutton">Add to cart</button></td><td height="40px" bgcolor="white"><font color="black">Rs.250 </font>&nbsp;<input type="number" name="farm"><button class="vbutton">Add to cart</button></td></tr>
 <tr><td height="390px" background="paneertikka.jpg"></td><td height="390px" background="mushroom.jpg"></td></tr>
 <tr><td height="40px" bgcolor="white"><font color="black">Rs.450 </font>&nbsp;<input type="number" name="paneer"><button class="vbutton">Add to cart</button></td><td height="40px" bgcolor="white"><font color="black">Rs.450 </font>&nbsp;<input type="number" name="mush"><button class="vbutton">Add to cart</button></td></tr>
 <tr><td height="390px" background="allveggies.jpg"></td><td height="390px" background="crowded.jpg"></td></tr>
 <tr><td height="40px" bgcolor="white"><font color="black">Rs.600 </font>&nbsp;<input type="number" name="veggies"><button class="vbutton">Add to cart</button></td><td height="40px" bgcolor="white"><font color="black">Rs.600 </font>&nbsp;<input type="number" name="crowded"><button class="vbutton">Add to cart</button></td></tr>
</table>
</div>
<div class="innercon2">
<table class="veg" cellspacing="10px">
 <tr><th colspan="2" bgcolor="red"><font size="6px">Non-vegetarian pizzas</font></th></tr>
 <tr><td height="400px" background="bbqchi.jpg"></td><td height="400px" background="medchi.jpg"></td></tr>
 <tr><td height="40px" bgcolor="white"><font color="black">Rs.330 </font>&nbsp;<button clas<input type="number" name="bbq">s="nvbutton">Add to cart</button></td><td height="40px" bgcolor="white"><font color="black">Rs.330 </font>&nbsp;<input type="number" name="med"><button class="nvbutton">Add to cart</button></td></tr>
 <tr><td height="400px" background="chitikka.jpg"></td><td height="400px" background="meat.jpg"></td></tr>
 <tr><td height="40px" bgcolor="white"><font color="black">Rs.470 </font>&nbsp;<input type="number" name="tikka"><button class="nvbutton">Add to cart</button></td><td height="40px" bgcolor="white"><font color="black">Rs.470 </font>&nbsp;<input type="number" name="meat"><button class="nvbutton">Add to cart</button></td></tr>
 <tr><td height="400px" background="chifull.jpg"></td><td height="400px" background="pepperoni.jpg"></td></tr>
 <tr><td height="40px" bgcolor="white"><font color="black">Rs.620 </font>&nbsp;<input type="number" name="chifull"><button class="nvbutton">Add to cart</button></td><td height="40px" bgcolor="white"><font color="black">Rs.620 </font>&nbsp;<input type="number" name="pep"><button class="nvbutton">Add to cart</button></td></tr>
</table>
</div>
</div>
</form>
</body>
</html>
