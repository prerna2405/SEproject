<html><?php

$username=$_POST['username'];
$name=$_POST['name'];
$phone=$_POST['phone'];
$mail=$_POST['mail'];
$password=$_POST['pw'];

$link = mysqli_connect('localhost', 'root', '');
mysqli_select_db($link,'fp_project');
if (!$link)
{
die(mysql_error());
}

$sql1="insert into user_details values('$username','$password','$name','$phone','$mail')";
$res1=mysqli_query($link,$sql1) or die(mysql_error());

if ($res1)
{ 
  echo "<script type='text/javascript'>alert('Registration successful!');</script>";
  header('location:FPlogin.htm');
}
else
{
   echo "<script type='text/javascript'>alert('Registration failed!');</script>";
   header('location:FPsign_up.htm');
}
?></html>