<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: FPlogin.htm");
exit(); }
?>

<html>
<head>
<title>Welcome <?php echo $_SESSION["username"] ?></title>
<link rel="icon" href="D:\SEM3\soft engg\project\Feaster'spizza\logo.jpg"/>
<style>

.footer{
   top: 94%;
   position:fixed;
   bottom:0;
   width:100%;
   height: 25 px;
   background: rgba(0,0,0,0.5);
   color: #F0F8FF;
}
header{
 position: relative;
 color: black;
 width: 100%;
 margin-right:3px;
}
.topnav {
  overflow: hidden;
  background-color: black;
  margin-right:6px; 
  border-bottom:4px red solid;
}

.topnav a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
    background-color: #4CAF50;
    color: white;
}
.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
.heading1 h4{
    display: block;
    background: black;
    margin-left:44%;
    color: #E9967A;
}
.mySlides {display:none}

/* Slideshow container */
.slideshow-container {
  max-width: 100%;
  position: relative;
  top: 45;
  bottom: 0;
  left: 0;
  right: 0;
  margin: ;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: black;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor:pointer;
  height: 13px;
  width: 13px;
  margin: 70px 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}

td a:hover {
   display: block;
   cursor: pointer;
   height: 100%;
   width: 100%;
   background-color: rgba(0,0,0,0.8);
   transition: background-color 0.2s ease;
}

a:link{
  color: white;
  text-decoration: none;
}

a:visited{
  color: white;
  text-decoration: none;
}


</style>
</head>
<body style="background-color:#333">
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">Custom pizza</a>
  <a href="#">Categories</a>
  <a href="#">My account</a>
  <a href="#">About us</a>
  <a href="#">Contact us</a>
</div>
<header>
<div class="topnav">
<a href="FPlogout.php">Logout</a>
<a href="FPcart.php">My Cart</a>
<a class="active" href="_self">Home</a>
<div style="float:left">
<span style="font-size:30px;cursor:pointer;color: white" onclick="openNav()">&#9776; Menu</span>
</div>
<div class="heading1">
<h4>FEASTER'S PIZZERIA</h4>
</div>
</div>
</header>
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="slide1.jpg" style="width:100%">
  <div class="text">Use the arrows to navigate</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="slide2.jpg" style="width:100%">
  <div class="text">Use the arrows to navigate</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="slide3.jpg" style="width:100%">
  <div class="text">Use the arrows to navigate</div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

<table align="center"><tr><th><p style="color: white;"> CATEGORIES</p></th></tr></table>

<hr style="heigth:3px; width:94%; align: center;color: red;"> 
<div>
<table width="100%" cellspacing="90px" cellpadding="10px">
<tr>
  <td background="catpiz.jpg" height="330px" width="330px" class="pizza"><p align="center"><font color="white" size="15px"><a href="FPpizza.php">PIZZAS</a></font></p></td>
  <td background="dessert.jpg" height="330px" width="330 px" class="dessert"><p align="center"><font color="white" size="15px"><a>DESSERTS</a></font></p></td>
  <td background="bread.jpg" height="330px" width="330 px" class="bread"><p align="center"><font color="white" size="15px"><a>BREADS</a></font></p></td>
</tr>
</table></div>

<hr style="heigth:3px; width="94%"; align: center; background-color:white">
<table width="100%">
<tr><th align="center" color="white"><font color="#333">put attractive text here</font></th></tr>
</table>
<hr style="heigth:3px; width=94%; align: center; background-color:white"> 
<div class="footer">
<center>Hungry? Have a feast !<br>@Copyright. A & T pvt. ltd. All Rights Reserved.</center>
</div>
</body>
</html>