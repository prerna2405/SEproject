<?php
 session_start();
 
 $conn= mysqli_connect('localhost','root','');
 mysqli_select_db($conn,'fp_project') or die(mysql_error());
 
 $username=$_POST['username'];
 $password=$_POST['pw'];

 if ($username=='' || $password=='')
  {
    echo "<script type='text/javascript'>alert('Please enter proper values!');  window.location = 'FPlogin.htm';</script>";
  }
 
  $sql1= "select username, password from user_details where username='$username' and password='$password'"; 
  $result = mysqli_query($conn,$sql1) or die(mysql_error());
  $rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['username'] = $username;
	    header("Location: FPhome.php");
         }
         else{
	      echo "<script type='text/javascript'>alert('Incorrect username or password!');  window.location = 'FPlogin.htm';</script>";
	     }
?>